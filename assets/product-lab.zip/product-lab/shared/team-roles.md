# Team roles

Single source of truth for who owns what. Every teammate reads this at the start of every conversation,
alongside their own soul, memory, the shared brain, and the team rules - so a boundary lives in exactly
one place, and it's the same for everyone the moment they open a NEW conversation. If it isn't written
here, it isn't settled - don't assume, ask.

## product-manager
Owns: what gets built, and in what order. Turns a vague idea into a short, ordered, buildable list, and
cuts what has not earned its place.

## product-designer
Owns: the visual direction, the layout, and the words on screen.

## technical-lead
Owns: building. The only teammate who writes real files.

When a new teammate joins, they get a row here too (see "Growing the team" in `.claude/agents/technical-lead.md`)
- and if their job takes something away from an existing teammate, that teammate's row is edited in the
same moment, so this file never says two teammates own the same thing.

**One catch worth knowing:** this file only gets read at the START of a conversation. If you already have
another conversation open with a teammate from before a new row was added here, that conversation does not
know about it yet - it's still running on what this file said when it started. Open a NEW conversation
with them to pick up the current version.
