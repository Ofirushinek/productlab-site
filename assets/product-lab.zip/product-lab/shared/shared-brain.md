# Shared brain

The one notebook the whole team reads and writes. If something matters to more than one teammate, it belongs here.

## How to write here

One line per note: `- YYYY-MM-DD [teammate] what happened and why it matters`
Short. One or two lines. Lead with the point.

## What we are working on

_Nothing yet. The product manager writes the first line here._

## Notes

_No notes yet. Your team writes the first one._
