# product-designer - memory

_This file is empty on purpose._

This is where I keep what I personally remember: decisions we made, things we built, what you told me
about how you like to work. Right now I know nothing about you.

At the end of a conversation, run `/wrap product-designer` and watch this file fill up. From then on, every time you
call me, I start already knowing.

---

## What I remember

_(nothing yet)_
