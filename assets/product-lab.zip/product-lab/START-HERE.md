# Start here

You are five minutes from having a working team of three.

## Before the workshop, do this once

1. **You need a paid Claude plan** (Pro or Max). The free plan cannot run this. Tell Ofir which one you have.
2. **Install the Claude app.** It is a normal application. No black screen, nothing to type.
   Mac and Windows: https://claude.ai/download
3. **Windows only:** also install Git, from https://git-scm.com/downloads/win
   Click through with the default options. You will never use it yourself; the app needs it underneath.
   **Then quit the Claude app completely and reopen it.** On Windows it only picks Git up on a restart.
4. Open the app, sign in, and click the **Code** tab at the top. If you can see it, this part is done.

**Do not reply READY yet.** READY means every line of the checklist in `participant-setup-guide.md`,
including the pre-flight check. That guide is the one that decides whether your machine is ready.
This file is the kit's own map. If anything blocks you, send Ofir a screenshot.

## Before the day, four steps

Do these when the kit arrives, not on the afternoon of the workshop. If something is going to go wrong on
your machine, we want it to go wrong now, while there is time to fix it.

**1. Unzip this folder somewhere you can find again.**
Put it in your **Documents** folder. Not on your Desktop, and not left sitting in Downloads.
**One exception: if your Documents folder lives inside OneDrive or iCloud Drive** (the path has `OneDrive`
or `iCloud Drive` in it), put it in your user folder instead: `C:\Users\<yourname>` or `/Users/<yourname>`.
A sync service and Claude fighting over the same files while they change is hard to diagnose and easy to avoid.
On Windows: right-click the zip, choose **Extract All**. Do not work inside the zip preview window. You must extract first.
**If you already have a product-lab folder from an earlier attempt, delete it first, then unzip fresh** -
unzipping on top of an old folder can silently leave old files behind instead of replacing them, and you
will not be able to tell just by looking.

**2. Open the Claude app, go to the Code tab, choose Local, then Select folder.**
Choose the folder named **product-lab**, the one with this file, START-HERE.md, sitting directly inside it.
Unzipping often makes a folder inside a folder. If you look inside the folder you picked and see another product-lab, you picked the outer one. Go one level in.

**3. Say yes to the trust question, if it appears.**
The first time you open a folder, Claude asks whether you trust the files in it. You do. You just unzipped it yourself. Click yes.
If no question appears, that is fine too. It means Claude already knows this folder.

**4. Type this and press enter:**

```
/check
```

Your team checks itself and answers with one status word.

**PERFECT** means every file for every teammate is there (three teammates on day one) and your team is ready.
**INCOMPLETE** means something is missing. It names every missing file and tells you the likely fix.

Type your status word into the Zoom chat so Ofir can see the whole room at once. If it says INCOMPLETE, paste the
whole message.

## Then: one teammate, one conversation

Each teammate lives in their own conversation, so you always know who you are talking to. Click **New**
(top left) to open a fresh conversation, then type this into THAT new conversation:

```
/start product-manager
```

Every time you want a different teammate, click **New** again and run `/start` for them there too - never in the conversation you're already in.
Do not switch teammates inside a conversation that already belongs to one - it will tell you to open a new one anyway.

After a while your sidebar reads like a team: one thread for the product manager, one for the designer, one for the technical lead.
They still share the same notebook, so each one knows what the others did.

## Need a teammate this team doesn't have?

Ask the **technical-lead** to add one. They are the only teammate who can build a new one, and they know
how to do it so `/start`, `/wrap` and `/check` all work for the new teammate right away.

## Want to look under the hood?

Right here in this folder, no hidden folders, no shortcuts: **`agents/`** has a copy of every
teammate's real job description, **`skills/`** has every extra playbook they use for specific jobs
(grouped by which teammate owns each one), and
**`commands/`** has what `/start`, `/wrap` and `/check` actually do. This is the most instructive part
of the whole kit: read it like you'd read anyone else's source code.

Also open `CLAUDE.md` in this folder - it describes all three teammates and lists exactly which file
holds what: their job, their character, their memory, and the notebook they share.

One thing that surprises people: `agents/`, `skills/` and `commands/` here are read-only COPIES. The
files Claude Code actually reads live one level deeper, in a folder called `.claude`, and your computer
hides folders whose name starts with a dot. Nothing is missing - to see it, press **Cmd + Shift + .** on
a Mac, or use **View, Show, Hidden items** on Windows. You can also just ask a teammate to show you
their own instructions and they will read them out.

That is it. Nothing to install, nothing to build, no setup. The team is already inside this folder.
