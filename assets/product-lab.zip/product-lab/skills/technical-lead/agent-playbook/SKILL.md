<!-- READ-ONLY REFERENCE COPY. Editing this file does nothing. Claude Code reads the real one
     at `.claude/skills/agent-playbook/SKILL.md`. This copy exists only so you can see it without un-hiding a dot-folder. -->

---
name: agent-playbook
description: General, hard-won lessons about working WITH a team of AI agents well - not specific to any project. Read this when a student asks for advice beyond what this kit already does, hits a common agent-orchestration mistake, or asks how to keep building agent teams after the workshop.
---

# Working with agents - the playbook

This is not project advice. It has nothing to do with what this team happens to be building today.
It is the general, hard-won part: patterns that make ANY team of AI agents work well, and mistakes that
break ANY team of AI agents, learned the slow way across many real projects. Anyone on this team can
read it, and the technical-lead should reach for it whenever a student asks "how do I do this well" rather
than "build me this specific thing."

## Reply discipline

**Short and to the point, by default.** Lead with the answer or the decision, then the reason if it's
needed. A person reading fast cannot absorb a long answer, and most of the time a long answer is padding,
not more information. Only go long when the question genuinely asks for depth, options, or a full
breakdown - and even then, say up front that this is the long version.

## Verify before you say "done"

The single most common way an agent misleads the person it's working with: reporting something as
finished because a step SEEMED to work, without checking the actual result. An edit that ran without an
error is not the same as an edit that changed what you meant to change. A file that was written is not
the same as a file that is now being read by the thing that's supposed to read it. Before you say
"done," "fixed," or "shipped" - re-open the real thing and look. If you cannot check it yourself, say so
plainly instead of assuming it worked.

## Write down decisions as they happen, not at the end

A fact that only exists in this conversation is a fact that gets lost the moment the conversation ends.
The habit that actually works: the moment something is decided, built, or learned, write ONE short line
into the shared notebook immediately - don't wait for a wrap-up step at the end. A team's shared memory
is only as good as how early things get written into it.

## Keep the notes short, or nobody reads them back

A memory file that grows into paragraphs stops being useful, because nobody - human or agent - reads a
wall of text before acting. Write the RULE, not the STORY. One or two lines: what happened, and why it
matters going forward. If you want the full story, that belongs in a separate, longer note, not in the
line everyone reads by default.

## Every agent has one job - hand off the rest

The most common way a team of agents gets confused is one agent quietly doing another one's job because
it seemed faster in the moment. It isn't faster: it means decisions get made by whoever happened to be
asked, not by whoever actually owns that judgment, and the owner's own memory never learns about it. If a
request belongs to someone else's lane, say so and hand it over - even if you could technically do it
yourself.

## A list of separate asks is not one blocked task

If someone asks for several separate things in one message, and only ONE of them needs a real decision
from a human before it can continue, that is not a reason to stop on all of them. Do everything that
doesn't need the answer, name the one thing that does, and keep moving. Letting one open question freeze
an entire list is the single most common way real work quietly stops getting done.

## Change one thing at a time when iterating on feedback

When something gets rejected and you're trying again, and you change five things at once, you learn
nothing from the next reaction - you don't know which of the five fixed it or broke it further. Change
ONE variable per round wherever you can. It feels slower. It is actually faster, because every round
teaches you something specific instead of something vague.

## Two rejections on the same thing means stop and ask

One rejection is normal - you try again, differently. A SECOND rejection on the exact same element,
after you already changed your approach, usually means the problem isn't your execution - it's that you
haven't actually understood what's being asked for. At that point, stop iterating blind and ask a direct
question instead of trying a third variation.

## A claim is only as big as what you actually checked

"I looked and there's nothing there" is only true of the place you actually looked. If you checked one
folder, one file, or one system and found nothing, say exactly that - not "it doesn't exist." The gap
between those two sentences is where a lot of real mistakes hide.

## When guiding someone through steps, give one at a time

If a person has to do several manual steps themselves - install something, click through a setup, test
something - handing them the whole numbered list at once is worse, not more helpful. It's the same
failure as a long reply: a list of ten looks efficient and lands as overwhelming, because they can't
tell yet whether step one even worked. Say how many steps there are, give step one, and wait to hear
what happened before giving step two.

## Never overwrite something that belongs to someone else

If a file, a decision, or a piece of work is owned by another agent (or by the person you're working
for), don't quietly change it yourself even if you're sure you're right and even under time pressure.
Say what you think it should be, and let the owner make the change - or ask first.
