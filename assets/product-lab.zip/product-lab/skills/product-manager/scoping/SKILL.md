<!-- READ-ONLY REFERENCE COPY. Editing this file does nothing. Claude Code reads the real one
     at `.claude/skills/scoping/SKILL.md`. This copy exists only so you can see it without un-hiding a dot-folder. -->

---
name: scoping
description: How to turn a vague idea into a short, ordered, buildable list - and what to cut. Read this whenever a brief is fuzzy, a list is getting long, or it's time to decide what ships first.
---

# Scoping - turning a vague idea into a short, ordered list

This is a method, not a checklist for one project. It works on any idea, in any domain.

## 1. Ask what success looks like before you plan anything
"What are we building" is the wrong first question. Ask what DONE looks like, in one sentence, before
you list a single feature. If nobody can answer that yet, that is the actual first task - not building.

## 2. Write the list, then cut it in half
A first list is always too long, because everything sounds necessary while you're imagining it. Write
it anyway, then go back and remove everything that isn't required to prove the core idea works. A list
of five is usually more honest than a list of twelve - not because five is a magic number, but because
forcing the cut is what surfaces which three or four things actually matter.

## 3. Every item earns its place, or it's out
For each item on the list, be able to say in one sentence why it's there. "It would be nice" is not a
reason. "The thing doesn't work without it" is. If you can't state the reason quickly, that's the
signal it doesn't belong in this version.

## 4. Order by what teaches you the most, not by what's easiest
The first thing to build is whichever one tells you fastest whether the whole idea holds up - not
whichever one is quickest to knock out. Easy-first feels productive and teaches you nothing; risky-first
is uncomfortable and is usually the actual point.

## 5. Say what you're deliberately NOT doing, out loud
A scoped plan names its own boundary. "We are not building X yet, and here's why" prevents the same
idea from quietly sneaking back in three messages later disguised as a "quick addition."

## 6. Saying no is the job, not a failure of the job
Every idea that gets cut can come back later if it earns its place then. Protecting a small, coherent
first version from good ideas arriving at the wrong time is the actual value a scoping conversation
adds - not coming up with more ideas.

## Questions to ask
- "What does success look like, in one sentence?"
- "If we could only build ONE of these, which one, and why?"
- "What are we explicitly not doing in this version?"
- "Does this item earn its place, or does it just sound good?"

## Output format
A numbered list, most important first, five items or fewer. Each item gets one line saying why it's
there. End with one line naming what was deliberately cut and why.
