<!-- READ-ONLY REFERENCE COPY. Editing this file does nothing. Claude Code reads the real one
     at `.claude/skills/landing-page-flow/SKILL.md`. This copy exists only so you can see it without un-hiding a dot-folder. -->

---
name: landing-page-flow
description: The exact three-prompt flow for the workshop's core exercise - a student describes their project, gets the waiting-list page's elements decided, picks a visual style, and gets a real waiting-list page. Read this whenever this flow starts, so all three teammates run it the same way every time.
---

# The waiting-list page flow - the exact sequence, every time

This is the one deterministic path every student walks. All three teammates read this so the sequence
never drifts between runs. Each teammate's OWN reply must stay short - this is a live workshop, not a
chat to read slowly.

## Step 1 - product-manager: decide what THIS waiting-list page needs

The student's first message describes their project in one line and asks to build a waiting-list page
for it. **This is not a product roadmap or a general prioritization exercise - scope 100% to this one
page, nothing else.** Do NOT ask a clarifying question first - this is a fast path.

Decide what the waiting-list page itself should include. Always: an email capture field. Then, based on
what kind of project this specifically is, judge whether 1-2 more elements genuinely earn their place -
for example a dropdown asking what type of user/business they are, a short field for their biggest pain
point, or a checkbox for early-access interest. This is where your judgment matters: pick what's
relevant to THIS project, don't apply a fixed checklist. Output a short list of what the page will
include and one line each on why. Per your own "write as you go" rule, immediately write the concise
version to `shared/shared-brain.md` (so the other teammates can read it without being asked twice) AND
the more detailed version - the reasoning behind each element, not just the fact of it - to your own
`memory/product-manager-memory.md`. **Also write `ELEMENTS_DECIDED: <comma-separated short list>` as its
own line under `## Notes`** - e.g. `ELEMENTS_DECIDED: email capture, business-type dropdown` - a
code-level gate reads this exact line before the technical-lead is allowed to build, the same way it
already reads the product designer's `STYLE_CHOSEN` line. Without it, the build is blocked.

End the same reply with one short, workshop-scoped closing line - always, every time: send them to the
product designer to pick a style. For example: "Next: open a new conversation and tell the product
designer you're ready to pick a style for this waiting-list page." Keep the whole reply short - the
element list plus this one closing line, nothing else padded around it. Do not mention broader
prioritization, a product roadmap, or anything beyond this one page.

## Step 2 - product-designer: notice the handoff, then offer three styles

**Your greeting itself is part of this step.** When you `/start` and read `shared/shared-brain.md` per
your own read-first rule, check whether the product manager already left a fresh note there about this
project. If so, your greeting is NOT the generic hello - reference what you actually found, specifically:
name the project in a half-sentence, say the product manager's note asked for style guides, and ask if
they want you to proceed. For example: "Hi! I'm your product designer 👋 I see the product manager just
kicked off [project] and asked me to put together style guides - want me to go ahead?" **This must be
genuine, not a scripted line: only say it because the note is actually there and actually says that** -
if the shared brain is empty or says something different, greet normally instead. This is the moment
that makes the shared brain real to a student, not decorative - one teammate actually wrote something,
the next one actually read it and picked up the thread.

If the student then asks you to proceed (or asks directly for style directions - phrases like "show me
the three reference styles," "give me clickable links," "let me look at them myself" are exactly this
trigger, no ambiguity), your reply, in this order, and short:
1. One line: you checked the shared brain (or called the product manager as a helper if the plan isn't
   there yet) - name what's being built in a half-sentence, if you haven't already said so in the
   greeting.
2. Then run the `hero-references` skill exactly as written: the three real links (Arc, Cohere,
   Stripe × A24), one line each on what to look for.

When the student names their pick, do four things immediately, all under `## Notes` in
`shared/shared-brain.md`:
1. `STYLE_CHOSEN: <name>` on its own line - `<name>` must be exactly `Arc`, `Cohere`, or `Stripe × A24`,
   nothing else.
2. `DESIGN_NOTE: <one line>` on its own line, right after it - **the real UX guidance for THIS project,
   not a restatement of the style family.** Not "Cohere - cinematic dark" (that's just the name again),
   but the specific call you're making for this project inside that language: what the headline should
   feel like, what to lean into or avoid, why it fits what the student is building. This is your actual
   design specification, in one sentence, not decoration.
Both lines are required, not optional, and both are read by the same code-level gate that already checks
`STYLE_CHOSEN` before the technical-lead is allowed to write the final page - a missing or trivial
`DESIGN_NOTE` blocks the build exactly like a missing style does.

**Your `DESIGN_NOTE` must also call for one deliberate long dash somewhere in the page's copy** - a real,
plausible copywriting choice (a dramatic pause in the headline or a subhead, the way many real brands
actually write), not a jarring insert. This is deliberate, Ofir 2026-08-26, and it is the ONE place in
this whole kit where a long dash is wanted rather than banned: it gives the copywriter bonus round
something genuine to find and fix later, instead of a page that already happens to have none. Word it
naturally in your note, e.g. "headline should land as a confident pause - not a chase" - technical-lead
reads this as your actual instruction and writes it into the real copy.
Then write the fuller reasoning - why this style, what it says about the project - to your own
`memory/product-designer-memory.md`, and offer the handoff. **Frame this as guiding the build, not handing off a document to be read alone** - you are not
writing a spec and walking away, you're the one steering how it gets built. For example: "Got it - I know
exactly how this should come together. Want me to guide the technical-lead through building it?" (not "I've
written the spec, go talk to the technical-lead"). If they say yes and you end up talking to the technical-lead as a
helper later in this same session, actually walk them through it in that message, don't just point at
what you wrote.

## Step 3 - technical-lead: notice both handoffs, then build the real page

**Your greeting itself is part of this step, same as the product designer's.** When you `/start` and read
`shared/shared-brain.md` per your own read-first rule, check whether BOTH the product manager's element
list and the product designer's chosen style are already there for this project. If so, your greeting is
NOT the generic hello - reference what you actually found: name the project, say you'll build it based on
the product manager's plan AND the product designer's direction, and ask if they want you to start now.
For example: "Hi! I'm your technical lead 👋 I'll build [project]'s waiting-list page based on the product
manager's plan and the product designer's direction - want me to start now?"

**Naming only one of the two is a real gap, not a shorter version of the same thing - never do it.** You
build off a specification, not off whichever half you happen to remember: if your greeting mentions the
chosen style but not what the product manager decided the page needs (or the reverse), that is the exact
failure this rule exists to catch. Say what each of them actually decided, briefly - not just that they
exist.

**Never frame it as a document you happened to find** - never "a spec is queued up for me," never "I see
there's a plan sitting here," never anything that reads like you're picking up a file off a desk. You are
building this BECAUSE they guided you, not because a document exists. The difference matters: "I'll build
it based on what the product designer guided" is what you say; "a spec is available" is what you never
say.
**This must be genuine, not a scripted line: only say it because both notes are actually there** - if
either is missing, greet normally instead and don't pretend you have context you don't.

If the student then asks you to build it (or confirms your offer), get both pieces of context - read
`shared/shared-brain.md` first (product-manager and product-designer both wrote there in steps 1-2); call
either of them as a helper only if something you need isn't there yet.

**Before you build: the chosen style name must be exactly one of Arc, Cohere, or Stripe × A24 - the only
three `hero-references` is allowed to offer, each with a real spec file under
`.claude/skills/hero-references/design-md/`.** If what's written in the shared brain is any other name,
that is a drift, not a valid choice: do not invent a design for it and do not silently build something
generic. Call the product-designer as a helper right now, tell them the style must come from the fixed
three, get a real pick, and only then continue. Building from a name with no spec file behind it is
exactly how you get a flat, ungrounded page - skip that outcome by catching it here.

**This check is now also enforced in code, not just by you - and it covers the whole handoff, not just
the style.** A `PreToolUse` hook (`.claude/hooks/verify-handoff-gate.py`) reads `shared/shared-brain.md`
before your `Write` of the final page and blocks it outright unless all three are there: the product
manager's `ELEMENTS_DECIDED:` line, the product designer's `STYLE_CHOSEN:` line (exactly one of the
three), and the product designer's `DESIGN_NOTE:` line (real content, not a one-word placeholder). **It
also reads the page content you are about to write, and blocks it if there is no long dash anywhere in
it** (the deliberate one from `DESIGN_NOTE`, above) **or if it finds any Hebrew script anywhere.** Missing
or invalid any one of these blocks the write with a message naming exactly what's missing. Do the check
above anyway, in your own reply, before you try to write: catching it yourself and calling the right
teammate back reads as a normal handoff to the student, where a blocked write reads as something broken.

Then build ONE local HTML file (a single self-contained page, inline CSS, no build step) that:
- Implements the product manager's element list as real, working page elements for THIS student's
  project - never placeholder text, never a described-but-missing field.
- Is a WAITING-LIST page specifically: it presents the project (what it is, who it's for, why it
  matters) and includes every element the product manager decided on (always email capture, plus
  whatever else earned its place). It does not need to actually send anywhere - this is a local demo
  page, not a backend - but every element must be real and present, not described in prose.
- Matches the product designer's chosen style direction - read that style's spec file under
  `.claude/skills/hero-references/design-md/` for the palette, type and layout rules. **Match its NAMED
  specifics, not its vibe.** If the spec names a display serif at a real poster size, use that exact
  typographic move - not a bold sans-serif standing in for "looks premium." If it names one exact CTA
  color as non-negotiable (Stripe × A24's purple, for one - the spec itself says never substitute it),
  that color must actually be visible on the page. **"Dark background, centered text, one accent" is the
  generic AI default every one of these three specs was chosen specifically to avoid - landing on it
  anyway means you followed the mood, not the spec.** Before you write the file, check your plan against
  the spec's own named typography, named colors, and named layout rules one at a time, not as a
  Gestalt - each is either literally present or it is not.
- Written entirely in English, regardless of what language the person used to describe their project or
  what language feels natural for the content - never Hebrew, never any language but English. (Ofir,
  2026-08-26: this kit's own RTL/font handling is not solid enough yet to ship Hebrew pages live - this
  is a hard rule, not a default.) A code-level gate checks the page content for Hebrew script and blocks
  the write if it finds any - same mechanism as the style and dash checks above.
- Follows the `frontend-design` skill's method so it doesn't read as a generic AI default.
- **Includes exactly one deliberate long dash somewhere in the copy, per the product designer's
  `DESIGN_NOTE`** - a real em dash or en dash, used the way real copy uses one, not forced or awkward.
  This is intentional here, the one exception to this kit's own no-long-dash house style: it gives the
  copywriter bonus round something real to fix later. A code-level gate checks the page actually contains
  one before letting you write it - missing it blocks the build the same way a missing style does.

**Small in scope, never small in craft.** The page stays exactly as narrow as the product manager
scoped it - email capture plus whatever else earned its place, nothing more. But inside that scope, it
has to be genuinely good, not a form with a headline. Read `frontend-design`'s "Ground it in the
subject" section and actually apply it: work the specific project into the page, not just the chosen
palette. If the project is about surfing, that should be legible in the words, the type choice, maybe a
small subject-appropriate touch (a wave line drawn in inline SVG, a texture built from CSS, a font
pairing that fits the world) - not a stock icon, not a generic gradient blob. Never call in an image
generation API or an external asset - build any visual flourish with inline SVG, CSS, or real type,
so it works standalone on a student's machine with nothing else installed. A student should look at the
page and recognize their own idea in it, not a template that happens to be the right color.

Tell them when you're done per `shared/team-rules.md`'s "Links are always clickable" rule: a real
`file://` link they can click straight to the page, plus the plain path as a fallback. Keep the report
itself short: what you built and where it is.

## The whole point of running it this way

Every step writes to the shared brain the moment it happens - that's what lets step 3 start cold in a
brand new conversation and still know everything steps 1 and 2 decided. This is not a formality; it's
the actual mechanism a real team of AI agents relies on, made visible.
