---
description: Save what happened into a teammate's memory and the shared brain. Usage: /wrap <teammate>
argument-hint: <technical-lead|product-manager|product-designer>
---

`$ARGUMENTS` is the teammate's name.

Save this conversation properly. Do this now, in order:

1. Look back over this conversation and pick out only what is worth keeping: decisions made, things built, preferences the person expressed, anything that would be a loss to forget. Ignore small talk and anything already written down.
2. Append it to `memory/<teammate>-memory.md` under `## What I remember`, as short dated bullets:
   `- YYYY-MM-DD - <the fact, and why it matters>`
   One or two lines each. Lead with the point.
3. Add ONE line to `shared/shared-brain.md` under `## Notes`, so the other two teammates know what happened:
   `- YYYY-MM-DD [<teammate>] <what changed and why the others should care>`
4. If the team is now working on something new, update the `## What we are working on` section too.
5. Reply with a short summary: what you wrote, and into which files. Then invite the person to open those files and read them, so they can see their team's memory with their own eyes.

Never invent something that did not happen in this conversation.

End with a `Next:` line: either `/wrap <the next teammate who was involved>`, or, if everyone is saved, tell them they can close this conversation and that a brand new one will already know what happened - that is the whole point, and they should try it.
