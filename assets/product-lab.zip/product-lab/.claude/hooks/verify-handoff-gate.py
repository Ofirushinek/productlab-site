#!/usr/bin/env python3
"""PreToolUse gate: blocks technical-lead from writing an HTML page unless the
full handoff is actually recorded in shared/shared-brain.md - not just the
style, the whole specification a real build should happen off of:

  ELEMENTS_DECIDED: <what the product manager decided the page needs>
  STYLE_CHOSEN:     <one of Arc, Cohere, Stripe x A24>
  DESIGN_NOTE:      <the product designer's real UX guidance for this project>

It also requires the page's own copy to contain one deliberate long dash
(Ofir, 2026-08-26) - the one intentional exception to this kit's own
no-long-dash house style, so the copywriter bonus round has something real
to find and fix later instead of a page that already has nothing wrong.

It also blocks the write outright if the page contains any Hebrew script
(Ofir, 2026-08-26) - this kit's RTL/font handling isn't solid enough yet to
ship Hebrew pages live, so every built page must be English, no exceptions.

Code-level, not a prompt - cannot be skipped by the model choosing not to read
a skill file, and cannot be satisfied by remembering only half the handoff.

Contract: Claude Code sends the tool call as JSON on stdin. Exit 0 = allow.
Exit 2 = block; stderr is shown to the model as the reason.
"""
import json
import os
import re
import sys

APPROVED_STYLES = {"arc", "cohere", "stripe x a24", "stripe × a24"}
APPROVED_STYLES_DISPLAY = "Arc, Cohere, or Stripe × A24"
MIN_DESIGN_NOTE_CHARS = 15


def normalize(name):
    name = name.strip().strip("*").strip()
    name = name.replace("×", "x")
    name = re.sub(r"\s+", " ", name)
    return name.lower()


def last_marker(content, marker):
    value = None
    for line in content.splitlines():
        m = re.match(rf"\s*{marker}:\s*(.+)", line)
        if m:
            value = m.group(1).strip()  # last one wins - most recent
    return value


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0  # never block on a parse failure we don't understand

    if payload.get("tool_name") != "Write":
        return 0

    tool_input = payload.get("tool_input", {}) or {}
    file_path = tool_input.get("file_path", "") or ""
    if not file_path.lower().endswith(".html"):
        return 0

    project_dir = payload.get("cwd") or os.environ.get("CLAUDE_PROJECT_DIR") or "."
    brain_path = os.path.join(project_dir, "shared", "shared-brain.md")

    if not os.path.isfile(brain_path):
        sys.stderr.write(
            "HANDOFF GATE: shared/shared-brain.md not found - cannot confirm a real handoff happened. "
            "Do not write the page yet.\n"
        )
        return 2

    with open(brain_path, encoding="utf-8") as fh:
        content = fh.read()

    elements = last_marker(content, "ELEMENTS_DECIDED")
    style = last_marker(content, "STYLE_CHOSEN")
    design_note = last_marker(content, "DESIGN_NOTE")

    missing = []
    if not elements:
        missing.append(
            "ELEMENTS_DECIDED (the product manager's element list - call them as a helper and get it "
            "recorded)"
        )
    if not style:
        missing.append(
            f"STYLE_CHOSEN (must be exactly {APPROVED_STYLES_DISPLAY} - call the product designer as a "
            "helper and get a real pick recorded)"
        )
    elif normalize(style) not in APPROVED_STYLES:
        missing.append(
            f"STYLE_CHOSEN is '{style}', which is not one of the three approved directions "
            f"({APPROVED_STYLES_DISPLAY}) - that is drift, not a valid choice. Call the product designer "
            "as a helper, get a real pick from the fixed three."
        )
    if not design_note:
        missing.append(
            "DESIGN_NOTE (the product designer's real UX guidance for this project - call them as a "
            "helper and get it recorded, not just the style name)"
        )
    elif len(design_note) < MIN_DESIGN_NOTE_CHARS or normalize(design_note) == normalize(style or ""):
        missing.append(
            f"DESIGN_NOTE looks like a placeholder ('{design_note}') rather than real guidance - call the "
            "product designer back for the actual specification, not a restatement of the style name."
        )

    page_content = tool_input.get("content", "") or ""
    # em dash U+2014, en dash U+2013 - escaped, not the literal glyph, so this file itself
    # still has zero long dashes, same as every other file in the kit (the ship gate bans
    # the literal character, not the concept)
    long_dashes = ("\u2014", "\u2013")
    if not any(dash in page_content for dash in long_dashes):
        missing.append(
            "the page's own copy has no long dash (em dash or en dash) anywhere - this build deliberately "
            "requires exactly one, per the product designer's DESIGN_NOTE, so the copywriter bonus round "
            "has something real to fix later. Add one natural, deliberate long dash to the copy (a "
            "headline or subhead pause, not a forced insert) and try again."
        )

    # Hebrew block: U+0590-U+05FF. Presence anywhere in the page is a hard block, no exceptions.
    if re.search(r"[\u0590-\u05FF]", page_content):
        missing.append(
            "the page contains Hebrew script - every built page must be English only, no exceptions "
            "(Ofir, 2026-08-26: this kit's RTL/font handling isn't ready to ship Hebrew live). Rewrite the "
            "page in English and try again."
        )

    if missing:
        sys.stderr.write(
            "HANDOFF GATE: the page cannot be built yet - shared/shared-brain.md is missing part of the "
            "specification. You build off a specification, not off memory of half a conversation.\n"
            + "\n".join(f"  - {m}" for m in missing)
            + "\n"
        )
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
