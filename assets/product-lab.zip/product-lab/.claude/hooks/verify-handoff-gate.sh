#!/bin/sh
# Portable launcher for the handoff gate.
#
# WHY THIS FILE EXISTS (CTO, 2026-08-27):
# settings.json used to run the gate as `python3 .../verify-handoff-gate.py`.
# On a machine with no working python3 that command exits 127, and Claude Code
# classifies ANY exit code other than 0 or 2 as NON-BLOCKING: the action just
# proceeds. So the gate silently did nothing while everything still looked fine.
# That is the worst possible failure for a safety gate. Two real machines hit it:
#   - Windows: hooks run under Git Bash, which ships no python3. Worse, Windows
#     puts a python3.exe App Execution Alias on PATH that only opens the Store,
#     so "is it on PATH" is not the same question as "does it run".
#   - macOS with no Xcode Command Line Tools: /usr/bin/python3 exists as a stub
#     that pops the "install developer tools" dialog and fails.
#
# So this launcher does two things:
#   1. Finds a python that ACTUALLY EXECUTES (not just one that is on PATH) and
#      runs the real gate, passing its exit code straight through.
#   2. If no python exists at all, it enforces the core seal itself, in shell,
#      using only tools Git Bash and macOS both always have. See FALLBACK below.
#
# It only ever exits 0 (allow) or 2 (block). It never exits 127.

set -u

PAYLOAD=$(cat)
GATE_DIR=$(dirname "$0")
PY_GATE="$GATE_DIR/verify-handoff-gate.py"

# ---------------------------------------------------------------- find python
# `command -v` is not enough. Both the Windows Store alias and the macOS
# developer-tools stub are on PATH and both fail when run. Execute a trivial
# program and only trust the interpreter if that succeeds.
runs_ok() {
  "$@" -c "import sys" >/dev/null 2>&1
}

PY=""
for CAND in python3 python; do
  if command -v "$CAND" >/dev/null 2>&1; then
    # macOS: /usr/bin/python3 with no Command Line Tools installed pops a GUI
    # dialog when executed. Detect that case WITHOUT running it, so no dialog
    # ever appears in the middle of a workshop.
    RESOLVED=$(command -v "$CAND" 2>/dev/null || echo "")
    if [ "$RESOLVED" = "/usr/bin/python3" ] || [ "$RESOLVED" = "/usr/bin/python" ]; then
      if command -v xcode-select >/dev/null 2>&1; then
        xcode-select -p >/dev/null 2>&1 || continue
      fi
    fi
    if runs_ok "$CAND"; then PY="$CAND"; break; fi
  fi
done

if [ -z "$PY" ] && command -v py >/dev/null 2>&1; then
  # Windows Python launcher. Real installs answer; the Store alias does not.
  if py -3 -c "import sys" >/dev/null 2>&1; then PY="py -3"; fi
fi

if [ -n "$PY" ] && [ -f "$PY_GATE" ]; then
  printf '%s' "$PAYLOAD" | $PY "$PY_GATE"
  exit $?
fi

# ---------------------------------------------------------------- FALLBACK
# No python anywhere. Enforce the part of the gate that is the actual seal:
# the build must happen off a recorded specification, never off memory of half
# a conversation. Those three markers live in a plain text file on disk, so no
# JSON parsing is needed to check them and nothing here is fragile.
#
# Deliberately NOT enforced in this path: the two content-level checks (the one
# deliberate long dash, and the Hebrew ban). Both would need the page body
# parsed out of the JSON payload in shell, which is exactly the kind of brittle
# string surgery that produces a FALSE block. A false block would strand a
# student mid-build, which is worse than the check being absent. Both rules are
# still carried in the technical-lead's own instructions. A machine on this path
# is a degraded machine and /check reports it as INCOMPLETE, by design.

# Only Write matters, and only when the target is the built page.
echo "$PAYLOAD" | grep -q '"tool_name"[ ]*:[ ]*"Write"' || exit 0
echo "$PAYLOAD" | grep -Eq '"file_path"[ ]*:[ ]*"[^"]*\.html"' || exit 0

PROJECT_DIR="${CLAUDE_PROJECT_DIR:-}"
if [ -z "$PROJECT_DIR" ]; then
  PROJECT_DIR=$(printf '%s' "$PAYLOAD" | sed -n 's/.*"cwd"[ ]*:[ ]*"\([^"]*\)".*/\1/p' | head -1)
fi
[ -z "$PROJECT_DIR" ] && PROJECT_DIR="."
BRAIN="$PROJECT_DIR/shared/shared-brain.md"

block() {
  printf 'HANDOFF GATE: the page cannot be built yet - shared/shared-brain.md is missing part of the specification. You build off a specification, not off memory of half a conversation.\n' >&2
  printf '  - %s\n' "$1" >&2
  exit 2
}

if [ ! -f "$BRAIN" ]; then
  printf 'HANDOFF GATE: shared/shared-brain.md not found - cannot confirm a real handoff happened. Do not write the page yet.\n' >&2
  exit 2
fi

# Last marker wins, same as the python gate: the most recent handoff is the real one.
marker() {
  grep -E "^[ ]*$1:[ ]*.+" "$BRAIN" 2>/dev/null | tail -1 | sed "s/^[ ]*$1:[ ]*//" | sed 's/[ ]*$//'
}

ELEMENTS=$(marker ELEMENTS_DECIDED)
STYLE=$(marker STYLE_CHOSEN)
NOTE=$(marker DESIGN_NOTE)

[ -z "$ELEMENTS" ] && block "ELEMENTS_DECIDED (the product manager's element list - call them as a helper and get it recorded)"
[ -z "$STYLE" ] && block "STYLE_CHOSEN (must be exactly Arc, Cohere, or Stripe x A24 - call the product designer as a helper and get a real pick recorded)"

# Normalise the same way the python gate does: strip bold markers, fold the
# multiplication sign to a plain x, collapse spaces, lowercase.
MULT=$(printf '\303\227')
STYLE_NORM=$(printf '%s' "$STYLE" | sed "s/\*//g; s/$MULT/x/g; s/[ ][ ]*/ /g; s/^ //; s/ $//" | tr 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' 'abcdefghijklmnopqrstuvwxyz')
case "$STYLE_NORM" in
  arc|cohere|"stripe x a24") : ;;
  *) block "STYLE_CHOSEN is '$STYLE', which is not one of the three approved directions (Arc, Cohere, or Stripe x A24) - that is drift, not a valid choice. Call the product designer as a helper, get a real pick from the fixed three." ;;
esac

[ -z "$NOTE" ] && block "DESIGN_NOTE (the product designer's real UX guidance for this project - call them as a helper and get it recorded, not just the style name)"

NOTE_LEN=$(printf '%s' "$NOTE" | wc -c | tr -d ' ')
NOTE_NORM=$(printf '%s' "$NOTE" | sed "s/\*//g; s/[ ][ ]*/ /g; s/^ //; s/ $//" | tr 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' 'abcdefghijklmnopqrstuvwxyz')
if [ "$NOTE_LEN" -lt 15 ] || [ "$NOTE_NORM" = "$STYLE_NORM" ]; then
  block "DESIGN_NOTE looks like a placeholder ('$NOTE') rather than real guidance - call the product designer back for the actual specification, not a restatement of the style name."
fi

exit 0
