# frontend-design

This skill is Anthropic's official `frontend-design` Agent Skill, included here unmodified.

- Source: https://github.com/anthropics/skills (skills/frontend-design)
- Licence: Apache License 2.0, full text in `LICENSE.txt`
- Bundled into the Product Lab starter kit on 2026-08-22

It gives your product designer a working method: decide the visual direction BEFORE writing
any code, name the palette and typefaces deliberately, choose one signature element the page
is remembered by, then critique that plan against the brief and revise anything that reads
like a generic default.

Your product designer loads it automatically. You can read it yourself: `SKILL.md`.
