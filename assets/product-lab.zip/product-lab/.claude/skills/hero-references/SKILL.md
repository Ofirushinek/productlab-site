---
name: hero-references
description: Use when a student asks for reference examples, inspiration, or style directions for their hero or landing page. Presents three real, external, live websites to look at - never a description, never a live web search, never one of the studio's own demo pages. Once the student picks one, pairs with the frontend-design skill to build the student's own hero in that visual language.
---

# Hero References

A student's hero page needs a real visual direction, not a generic AI default. This skill hands the
student exactly three real, live, external websites they can open themselves and look at - then builds
their OWN hero in the language of whichever one they pick.

## The rule, and why it's strict

**Always these exact three. Never a live web search for "more" or "different" options. Never a
description of a site instead of a link. Never one of the studio's own old demo pages as a reference -
those were branded to a different product (a workshop waiting list, its own screen counts) and mean
nothing next to a student's own product.**

**Never invent a fourth name, and never rename or reword these three, even if a different mood would
feel like a better fit for the student's brief.** These three are the only ones with a real spec file
behind them (`design-md/glass/arc.md`, `design-md/cinematic/cohere.md`,
`design-md/remix/stripe-x-a24.md`) - a made-up name has no spec file, which means step 2 has nothing real
to build from and the result is a flat, generic page. Before you send the list in step 1, check each of
the three names you are about to write against this file, word for word: **Arc**, **Cohere**, **Stripe
× A24**. If what you are about to send does not match, you have drifted - stop and use these three
instead of whatever you were about to write.

## Step 1 - present exactly these three

When a student asks for hero-page style references, reply with exactly this list - name as a real
clickable markdown link (`[Name](url)`, never a bare URL), one line on what to look for.

1. **[Arc](https://arc.net)** - soft glass: translucent panels, pastel radial gradients, one purple
   accent. Look at how light and layered everything feels.
2. **[Cohere](https://cohere.com)** - cinematic dark: a restrained, enterprise-confident mood with one
   warm gradient spent once. Look at how much weight the dark canvas carries with almost no color.
3. **[Stripe](https://stripe.com) × [A24](https://a24films.com)** - bold editorial grid: Stripe's
   precise grid discipline blended with A24's poster-scale type boldness. Look at Stripe for the grid,
   A24 for how big and confident the type gets.

Tell the student to actually open the links and look before picking - the three names alone aren't
enough to choose from.

## Step 2 - once they pick one, build their page in that language

Each option has a matching spec file in this skill folder - read the one that matches their pick before
you write anything:

- Arc → `design-md/glass/arc.md`
- Cohere → `design-md/cinematic/cohere.md`
- Stripe × A24 → `design-md/remix/stripe-x-a24.md`

Use it as your MATERIAL (the palette, type, and layout rules for that visual language) and the
`frontend-design` skill as your METHOD (how to plan, critique, and build a page well) - read both before
you write code. The spec tells you what the look is; `frontend-design` tells you how to execute any
look without it reading as an AI default.

Before you show the student anything, check your plan against `break-default-aesthetic.md` in this
folder - it lists the templated patterns (numbered feature cards, the same three "benefit" tiles, a
hero that's a big number over a gradient) that make a page look generic no matter which spec it's
following. If your plan matches one of those, revise it.

Build the STUDENT'S OWN hero - their product, their content, their name - never the studio's example
copy. The reference site and the spec file are for the visual language only.
