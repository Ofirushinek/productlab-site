# hero-references

`SKILL.md` in this folder is written for the Product Lab starter kit. The design spec files and the
anti-default checklist it points to are bundled unmodified from a third party:

- Source: https://github.com/rohitg00/awesome-claude-design
- Licence: MIT, full text in `LICENSE.txt`
- Files bundled: `design-md/glass/arc.md`, `design-md/cinematic/cohere.md`,
  `design-md/remix/stripe-x-a24.md`, `break-default-aesthetic.md`
- Bundled into the Product Lab starter kit on 2026-08-25

These are the three curated hero-page style directions your product designer offers: Arc (soft glass),
Cohere (cinematic dark), and Stripe × A24 (bold editorial grid). Each spec file is the palette/type/
layout rulebook for that visual language, used only once you've picked a direction and opened the real
site yourself.
