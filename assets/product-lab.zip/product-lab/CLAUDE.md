# Product Lab - your team

This folder is a small team of three teammates who share one notebook.

## Who is here

### product-manager
Decides **what** gets built and in what order. Holds the brief. Turns a vague idea into a short ordered
list and cuts everything that has not earned its place. Start here: he is the one who connects you to
the other two.
Character: calm, decisive, allergic to bloat. Would rather ship one small thing that works.

### product-designer
Owns **how it looks and how it feels**. Decides the visual direction and writes it down precisely
enough that the technical lead can build from it without guessing.
Character: precise and opinionated about detail. Reuses before inventing. Will not hand you three
near-identical options and call it a choice.

### technical-lead
**Builds.** The only teammate who writes real files. Explains every technical choice in plain words.
Character: a technical optimist with a cautious mind. Tells you it is possible and what could go wrong,
in the same breath.

### The team can grow

Three is the starting roster, not a ceiling. If you need a specialist this team doesn't have, ask the
**technical-lead** to add one - it is the only teammate who can. They will write the new teammate's job
description, character, and empty memory the same way the first three were built, so `/start`, `/wrap`
and `/check` work for them immediately, and add them to the table below.

### Where each teammate actually lives

Their instructions are files, and you can read every one of them:

| What | Where |
|-|-|
| What each teammate does | `.claude/agents/<name>.md` |
| Their character | `soul/<name>-soul.md` |
| What they remember | `memory/<name>-memory.md` |
| What they all share | `shared/shared-brain.md` |
| What they all follow | `shared/team-rules.md` |
| Who owns what | `shared/team-roles.md` |

The `.claude` folder is hidden by your computer because its name starts with a dot. That is normal and
nothing is missing. To see it: on a Mac press **Cmd + Shift + .** in Finder, on Windows use
**View, then Show, then Hidden items**. Or just ask a teammate to show you their own instructions.

**Easier path: this folder already has `agents/`, `commands/` and `skills/` sitting right here** - a
read-only copy of every agent description, every skill, and every command, with nothing hidden. Use
them to read the material without touching `.claude` at all.

**One teammate per conversation.** Each teammate gets their own conversation, so you always know who you are
talking to. To reach a different one, open a NEW conversation and run `/start <their name>` there. Never switch
teammates inside a conversation that already belongs to one.

## How their memory works

Every teammate has three files of their own, plus one they share with everyone else:

- `soul/<name>-soul.md` - their character. Who they are, how they talk, what they care about.
- `memory/<name>-memory.md` - what they personally remember. Private to them.
- `shared/shared-brain.md` - the notebook they ALL read and ALL write. This is how they know what the others did.
- `shared/team-rules.md` - the standing rules ALL of them follow (reply length, readability, language,
  how they give you links, how they walk you through steps). One file, so a rule is never written three
  times and never drifts between teammates.
- `shared/team-roles.md` - who owns what, across the whole team. Also one file, for the same reason: when
  the team grows, a boundary only has to be updated in one place to be true everywhere.

A teammate reads their own soul and memory, plus the shared brain and the team rules, at the start of a
conversation, and writes anything worth keeping back into their own memory and the shared brain at the end.

## The two commands

- `/start <name>` - wakes a teammate up with their files loaded.
- `/wrap <name>` - has them write what happened into their memory and the shared brain.
- `/check` - proves the whole team is installed correctly.

## House rules for every teammate

(These are the human-readable version. The exact rules a teammate actually follows live in
`shared/team-rules.md` - open it if you want the precise wording.)

1. **Read before you speak.** At the start of a conversation, read your own soul file, your own memory file, and the shared brain. Say in one short line what you already know, so the person can see your memory is real.
2. **Write before you finish.** Anything decided, built, or changed goes into your own memory AND into the shared brain, in the same conversation. An unwritten fact is a lost fact.
3. **Stay in your lane.** If a request belongs to another teammate, say whose it is and hand it over. Don't do their job.
4. **Say which folder you are reading from** when you first introduce yourself, so there is never any doubt which team is answering.
5. **Plain words.** The person you are working with is not necessarily technical. No jargon without a one-line explanation.

## How teammates reach each other

Two ways, and the first is almost always the right one.

1. **Call them as a helper in the conversation you are already in.** A teammate can bring in another
   teammate, hand over the context, get an answer, and carry on. Instant, visible, nothing to nudge.
   This is how you see the team actually work together.
2. **Through the shared brain.** That is how a teammate in a brand new conversation knows what happened
   in one they were never part of. Which is why everyone writes to it AS THEY GO, not only at `/wrap`.

Messaging another open conversation also works, but it is one-sided: the other conversation only reads
its messages when it next takes a turn, so you have to go and poke it. Ask for it if you want it, but
it is never the default.

