<!-- READ-ONLY REFERENCE COPY. Editing this file does nothing. Claude Code reads the real one
     at `.claude/commands/check.md`. This copy exists only so you can see it without un-hiding a dot-folder. -->

---
description: Meet your Product Lab team and confirm everyone is installed correctly
---

Check that this team is correctly installed and report it in plain words. Do NOT fix anything and do
NOT create anything, with exactly one deliberate exception: step 4 attempts one throwaway test write on
purpose, to prove the build gate is alive. Everything else is look and report only.

STEP 1 - find the current roster. `Glob` `.claude/agents/*.md`. Each file found is one teammate (there
are three on day one - technical-lead, product-manager, product-designer - and more if this team has grown
since).

STEP 2 - confirm every fixed, team-level file exists:
- `.claude/commands/` : `start.md`, `wrap.md`, `check.md`
- `.claude/settings.json`
- `.claude/hooks/` : `verify-handoff-gate.sh`, `verify-handoff-gate.py`
- `shared/shared-brain.md`
- `shared/team-rules.md`
- `shared/team-roles.md`

STEP 3 - for EVERY agent file found in step 1, confirm its two companion files also exist:
- `soul/<name>-soul.md`
- `memory/<name>-memory.md`

STEP 4 - prove the build gate is actually RUNNING on this machine, not just present.

This kit ships a code-level gate that stops the technical-lead building the page off a half-remembered
handoff. A gate that is installed but not running is the most dangerous state there is, because
everything still looks fine. Existence of the files proves nothing. Test it for real:

1. Read `shared/shared-brain.md`. If it already contains a line starting `STYLE_CHOSEN:`, this team has
   already started work, and the test below cannot give a clean answer. Skip to the reply and add the
   line: `Note: the team has already started work, so the build gate could not be tested cleanly.`
2. Otherwise, use `Write` to create `.claude/hooks/gate-probe.html` with exactly this content:
   `<html><body>gate probe</body></html>`
3. **Being BLOCKED is the pass.** If the write is refused with a message beginning `HANDOFF GATE:`, the
   gate is alive and doing its job. That is the result you want. Nothing was created, nothing to clean up.
4. **If the write SUCCEEDS, the gate is DEAD** on this machine. The status is INCOMPLETE. The file
   `.claude/hooks/gate-probe.html` now exists and is a harmless leftover from this test.

Then reply in EXACTLY one of these two shapes, and nothing else. The first line is always the status
line on its own - lead with the emoji, it is the "at a glance" signal before anyone reads a word.
Follow the same spacing this whole reply is written in: one idea per line, a blank line between ideas,
never a run-on sentence chaining a status, a fact and an instruction together.

**If everything from steps 2, 3 and 4 is there and the gate blocked the test write:**

> ✅ STATUS: PERFECT
>
> Welcome to Product Lab - your AI team just introduced itself.
> Your team is ready.
>
> 📁 Folder: <the full path of the folder you are running in>
> 👥 Teammates (<N> total): <every name found in step 1, comma-separated>
>
> I can see: each teammate's agent file, soul, and memory, the shared brain, the team rules, who owns what, and all three commands.
>
> 🔒 Build gate: tested and live. It refused a bad write just now, which is exactly right.
>
> Next: click **New** to open a fresh conversation - one teammate always gets their own conversation.
> In that new conversation, type `/start product-manager` to meet your product manager.

**If any file is missing, OR the gate did not block the test write:**

> ⚠️ STATUS: INCOMPLETE
>
> 📁 Folder: <the full path of the folder you are running in>
> Missing: <list every missing file by name, and if the gate failed its test, the line: the build gate is installed but NOT running on this machine>
>
> Most likely cause, if files are missing: you opened the wrong folder. Unzipping usually creates a folder inside a folder.
> Go back one level and choose the folder named product-lab, the one with START-HERE.md sitting
> directly inside it.
> Second most likely cause, if you have unzipped more than once: an old product-lab folder was still
> there, and the new unzip left old files behind instead of replacing them. Delete the whole folder and
> unzip fresh, then open THAT one in Claude.
> Most likely cause, if every file is present but the build gate did not run: this machine has no working
> Python and Claude could not start the gate. Your team still works; the automatic safety check does not.
> (If a teammate you recently added is what's missing a file, that's a build mistake, not a wrong
> folder - tell the technical-lead who created them.)
>
> Next: read this whole message out to your instructor.

Never write PERFECT unless you verified every file yourself, for every teammate currently in the
roster - not just the original three - AND watched the gate refuse the test write in step 4. A green
check that lies is worse than no check at all. There are only two possible status words: PERFECT and
INCOMPLETE. The emoji marks which one it is; it never replaces the word.
