# Prompts

This mirrors the workshop deck exactly. If you're re-running this flow for a new project later,
these are the same six prompts.

## 1. Check your team is there

In your existing conversation:

```
/check
```

Expect: `STATUS: PERFECT`, three teammates.

## 2. Brief your Product Manager

Click New before this.

New conversation:

```
/start product-manager
```

Then:

```
I want to build a waiting-list page for my project: [fill in: what your site/tool/app is and who it's for].
```

## 3. Your Designer shows you three real styles

Click New before this.

New conversation:

```
/start product-designer
```

Then:

```
Check with the product manager about this project, then show me the three reference styles you've prepared for this - give me real clickable links so I can look at each one myself.
```

## 4. Your Technical Lead builds the page

Click New before this.

New conversation:

```
/start technical-lead
```

Then:

```
Please build the waiting-list page, guided by the product manager's plan and the product designer's direction.
```

## 5. Recruit the teammate you are missing

Click New before this.

New conversation:

```
/start technical-lead
```

Then:

```
I want to add a new teammate to this team. I have not written their job description yet - ask me what you need to know, all of it in one message, and I will answer in one go. Then build them from my answer, not from your own guess.
```

## 6. Your new teammate weighs in on what you built

Click New before this.

New conversation:

```
/start <the teammate you just built>
```

Then:

```
Look at what we built today - the page, and the decisions behind it in the shared brain. Before you suggest anything, ask each of your teammates what they see from where they sit. Then give me your own judgment: what would you change, and why. Say which teammate changed your mind. Fix what is yours to fix.
```

## 7. Wrap up before you close

In the same conversation, end of session:

```
/wrap
```
